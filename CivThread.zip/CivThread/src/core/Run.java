package core;

import window.Frame_Principal;

public class Run {

	public static void main(String[] args) {
		new Frame_Principal();
	}
}
